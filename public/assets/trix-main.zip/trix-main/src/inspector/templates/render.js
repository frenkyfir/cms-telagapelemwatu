if (!window.JST) window.JST = {}

window.JST["trix/inspector/templates/render"] = () => `Syncs: ${this.syncCount}`
