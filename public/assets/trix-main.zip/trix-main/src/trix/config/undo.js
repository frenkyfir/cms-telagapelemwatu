const undo = { interval: 5000 }
export default undo
