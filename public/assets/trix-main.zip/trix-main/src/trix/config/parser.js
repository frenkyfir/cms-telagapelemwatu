export default {
  removeBlankTableCells: false,
  tableCellSeparator: " | ",
  tableRowSeparator: "\n",
}
