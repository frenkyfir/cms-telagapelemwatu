export default () =>
  `<style type="text/css">
    blockquote { font-style: italic; }
    li { font-weight: bold; }
  </style>

  <trix-editor class="trix-content"></trix-editor>`
