export default () =>
  `<style type="text/css">
    .trix-content figure.attachment {
      display: inline-block;
    }
  </style>

  <trix-editor class="trix-content"></trix-editor>`
